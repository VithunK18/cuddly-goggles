# Q-Bench – Quantum vs Classical Machine Learning Benchmarking Platform

[![Python](https://img.shields.io/badge/Python-3.12-blue.svg)](https://www.python.org/)
[![Qiskit](https://img.shields.io/badge/Qiskit-2.5.2-6929C4.svg)](https://qiskit.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.142-009688.svg)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-19.0-61DAFB.svg)](https://react.dev/)
[![TailwindCSS](https://img.shields.io/badge/TailwindCSS-v4-38B2AC.svg)](https://tailwindcss.com/)

> **Fair, Reproducible Benchmarking of Quantum and Classical Machine Learning under Identical Experimental Conditions.**

---

## 1. Project Objective

**Q-Bench** solves the pervasive problem of non-standardized comparisons between Quantum Machine Learning (QML) and Classical Machine Learning (CML). In contemporary academic literature, researchers frequently compare quantum algorithms against classical baselines using disparate data scalers, differing random subsamples, unaligned train/test partitions, or non-uniform performance metrics.

Q-Bench enforces a strict foundational axiom:

$$\textbf{Same Dataset} + \textbf{Same Preprocessing} + \textbf{Same Train/Test Split} + \textbf{Same Evaluation Metrics} = \textbf{Fair Comparison}$$

---

## 2. Architecture & Pipeline

```mermaid
flowchart LR
    A["Dataset Input\n(Iris, Breast Cancer, Wine, Digits, CSV)"] --> B["Standardized Preprocessing\n(StandardScaler + PCA Alignment)"]
    B --> C["Stratified Split\n(Deterministic Random Seed)"]
    C --> D["Classical ML Suite\n(Logistic Regression, SVM, Random Forest)"]
    C --> E["Quantum ML Pipeline\n(Qiskit VQC, ZZFeatureMap, RealAmplitudes)"]
    D --> F["Unified Metrics Evaluation\n(Accuracy, Weighted F1, Train Time, Infer Time)"]
    E --> F
    F --> G["Scientific Comparison Engine\n(Unbiased Empirical Assessment)"]
    G --> H["Interactive Dashboard & SQLite Archive\n(Circuit Inspector + CSV/JSON Reports)"]
```

---

## 3. Technology Stack

- **Frontend**:
  - React 19 + TypeScript + Vite
  - Tailwind CSS v4 (Quantum research dark theme)
  - Recharts (Interactive comparative bar charts)
  - Lucide React (Icons)
- **Backend**:
  - Python 3.12
  - FastAPI + Uvicorn (Asynchronous REST API)
  - scikit-learn (Classical ML: Logistic Regression, SVM, Random Forest, PCA, StandardScaler)
  - NumPy & Pandas (Data wrangling & linear algebra)
  - SciPy (COBYLA variational optimization)
- **Quantum Machine Learning**:
  - **Qiskit 2.5.2** (Quantum circuit synthesis, parameter binding, statevector simulation, ASCII visualization)
  - **Qiskit Machine Learning & Qiskit Algorithms**
  - **Variational Quantum Classifier (VQC)** with `ZZFeatureMap` and `RealAmplitudes` ansatz
- **Database**:
  - SQLite (Persistent experiment history archive with zero configuration)

---

## 4. Key Features

1. **Deterministic Reproducibility**:
   Every benchmark run records the dataset, random seed, train/test ratio, preprocessing transforms, software versions, and simulator backend.
2. **Judge-Friendly "Benchmark Configuration" Panel**:
   A dedicated panel displaying the exact boundary conditions used, proving zero data leakage.
3. **Real Qiskit Quantum Simulation**:
   Actually executes a parameterized quantum circuit simulation with genuine quantum gates (`H`, `RZ`, `CX`, `RY`), circuit depth calculation, and Qiskit ASCII layout.
4. **Interactive Dashboard & Recharts**:
   Comparative visualizations for Accuracy, F1-Score, Training Latency, and Inference Latency.
5. **Sample Datasets & CSV Upload**:
   Built-in standard datasets (Iris, Breast Cancer Wisconsin, Wine Recognition, Optical Digits) plus drag-and-drop CSV upload.
6. **Export Reports**:
   Instant single-click downloads in CSV and JSON formats, alongside print-friendly reporting.
7. **Instant "Demo Benchmark"**:
   One-click live benchmark on the Iris dataset that executes the genuine pipeline in ~4 seconds.

---

## 5. Quick Start Instructions

### Prerequisites
- Python 3.12+ installed
- Node.js (v18+) and npm installed

### Step 1: Start Backend

From the repository root:
```bash
# Activate the virtual environment
.\qbench_venv\Scripts\Activate.ps1

# Run the FastAPI server
cd q-bench\backend
python main.py
```
Backend will start at: `http://127.0.0.1:8000`  
API Swagger Docs: `http://127.0.0.1:8000/docs`

### Step 2: Start Frontend

In a separate terminal:
```bash
cd q-bench\frontend
npm.cmd run dev
```
Frontend will be available at: `http://localhost:5173`

---

## 6. API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Health check & Qiskit simulator status |
| `GET` | `/api/datasets/available` | List available built-in and uploaded datasets |
| `POST` | `/api/dataset/upload` | Upload a custom CSV dataset |
| `POST` | `/api/benchmark/run` | Execute fair benchmark across selected models |
| `GET` | `/api/experiments` | Retrieve all archived experiments |
| `GET` | `/api/experiments/{id}` | Retrieve specific experiment details |
| `DELETE` | `/api/experiments/{id}` | Delete experiment record |
| `GET` | `/api/export/csv/{id}` | Export benchmark summary as CSV |
| `GET` | `/api/export/json/{id}` | Export benchmark summary as JSON |

---

## 7. Quantum Machine Learning Considerations & Limitations

- **Hilbert Space Complexity**: Simulating an $n$-qubit quantum system classically requires maintaining a statevector of $2^n$ complex amplitudes. Q-Bench defaults to 4 qubits to balance rich quantum entanglement with interactive responsiveness.
- **Dimensionality Reduction**: For datasets with feature counts exceeding the selected qubit count, Q-Bench uses Principal Component Analysis (PCA) to align both classical and quantum feature spaces.
- **Empirical Honesty**: Q-Bench does not artificially boost quantum scores. On classical hardware, classical algorithms (SVM, RF) typically exhibit lower latency and high accuracy, reflecting the true state of current NISQ-era simulation.

---

## 8. Troubleshooting

- **Port in Use**: If port 8000 or 5173 is occupied, specify `--port 8001` for uvicorn or `--port 5174` for vite.
- **PowerShell Execution Policy**: Run npm via `npm.cmd` rather than `npm` on Windows systems with Restricted execution policies.
